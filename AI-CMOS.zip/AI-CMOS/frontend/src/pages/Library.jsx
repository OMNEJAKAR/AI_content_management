import React from "react";

export default function Library() {
  return (
    <div>
      <h2>Library</h2>
      <p>Manage and search your documents here.</p>
    </div>
  );
}
